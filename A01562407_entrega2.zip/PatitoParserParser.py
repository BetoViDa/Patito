# Generated from D:/Mty/Compis/patito/PatitoParser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,34,254,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,
        0,1,0,1,1,3,1,72,8,1,1,2,5,2,75,8,2,10,2,12,2,78,9,2,1,3,1,3,1,3,
        1,3,1,3,4,3,85,8,3,11,3,12,3,86,1,4,1,4,1,4,5,4,92,8,4,10,4,12,4,
        95,9,4,1,4,1,4,1,4,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,
        6,1,6,1,6,1,6,1,7,1,7,1,7,3,7,118,8,7,1,7,1,7,1,7,1,7,1,7,1,7,3,
        7,126,8,7,3,7,128,8,7,1,8,1,8,1,8,1,8,1,9,1,9,1,9,3,9,137,8,9,1,
        10,1,10,1,10,1,10,1,10,3,10,144,8,10,1,11,1,11,1,11,1,11,1,11,1,
        12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,3,13,162,8,
        13,1,14,1,14,1,14,1,15,1,15,1,15,1,15,3,15,171,8,15,1,16,1,16,1,
        16,1,17,1,17,1,17,1,17,3,17,180,8,17,1,18,1,18,1,18,1,18,1,18,1,
        18,1,18,3,18,189,8,18,1,19,3,19,192,8,19,1,20,1,20,3,20,196,8,20,
        1,21,1,21,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,23,1,23,
        3,23,211,8,23,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,25,1,25,
        1,25,1,25,1,25,1,25,1,26,3,26,228,8,26,1,27,1,27,1,27,1,27,1,27,
        3,27,235,8,27,1,28,1,28,1,28,1,28,1,28,1,28,1,29,1,29,1,29,1,29,
        1,29,1,29,1,29,1,29,1,29,3,29,252,8,29,1,29,0,0,30,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,
        56,58,0,3,1,0,11,12,1,0,25,26,1,0,3,4,252,0,60,1,0,0,0,2,71,1,0,
        0,0,4,76,1,0,0,0,6,79,1,0,0,0,8,88,1,0,0,0,10,99,1,0,0,0,12,101,
        1,0,0,0,14,127,1,0,0,0,16,129,1,0,0,0,18,136,1,0,0,0,20,143,1,0,
        0,0,22,145,1,0,0,0,24,150,1,0,0,0,26,161,1,0,0,0,28,163,1,0,0,0,
        30,170,1,0,0,0,32,172,1,0,0,0,34,179,1,0,0,0,36,188,1,0,0,0,38,191,
        1,0,0,0,40,195,1,0,0,0,42,197,1,0,0,0,44,199,1,0,0,0,46,210,1,0,
        0,0,48,212,1,0,0,0,50,220,1,0,0,0,52,227,1,0,0,0,54,234,1,0,0,0,
        56,236,1,0,0,0,58,251,1,0,0,0,60,61,5,5,0,0,61,62,5,1,0,0,62,63,
        6,0,-1,0,63,64,5,23,0,0,64,65,3,2,1,0,65,66,3,4,2,0,66,67,5,7,0,
        0,67,68,3,16,8,0,68,69,5,15,0,0,69,1,1,0,0,0,70,72,3,6,3,0,71,70,
        1,0,0,0,71,72,1,0,0,0,72,3,1,0,0,0,73,75,3,12,6,0,74,73,1,0,0,0,
        75,78,1,0,0,0,76,74,1,0,0,0,76,77,1,0,0,0,77,5,1,0,0,0,78,76,1,0,
        0,0,79,84,5,16,0,0,80,81,3,8,4,0,81,82,6,3,-1,0,82,83,5,23,0,0,83,
        85,1,0,0,0,84,80,1,0,0,0,85,86,1,0,0,0,86,84,1,0,0,0,86,87,1,0,0,
        0,87,7,1,0,0,0,88,93,5,1,0,0,89,90,5,22,0,0,90,92,5,1,0,0,91,89,
        1,0,0,0,92,95,1,0,0,0,93,91,1,0,0,0,93,94,1,0,0,0,94,96,1,0,0,0,
        95,93,1,0,0,0,96,97,5,24,0,0,97,98,3,10,5,0,98,9,1,0,0,0,99,100,
        7,0,0,0,100,11,1,0,0,0,101,102,5,6,0,0,102,103,5,1,0,0,103,104,6,
        6,-1,0,104,105,5,18,0,0,105,106,3,14,7,0,106,107,6,6,-1,0,107,108,
        5,19,0,0,108,109,5,20,0,0,109,110,3,2,1,0,110,111,3,16,8,0,111,112,
        5,21,0,0,112,113,5,23,0,0,113,13,1,0,0,0,114,115,5,1,0,0,115,116,
        5,24,0,0,116,118,3,10,5,0,117,114,1,0,0,0,117,118,1,0,0,0,118,128,
        1,0,0,0,119,120,5,1,0,0,120,121,5,24,0,0,121,122,3,10,5,0,122,123,
        5,22,0,0,123,124,3,14,7,0,124,126,1,0,0,0,125,119,1,0,0,0,125,126,
        1,0,0,0,126,128,1,0,0,0,127,117,1,0,0,0,127,125,1,0,0,0,128,15,1,
        0,0,0,129,130,5,20,0,0,130,131,3,18,9,0,131,132,5,21,0,0,132,17,
        1,0,0,0,133,134,3,20,10,0,134,135,3,18,9,0,135,137,1,0,0,0,136,133,
        1,0,0,0,136,137,1,0,0,0,137,19,1,0,0,0,138,144,3,22,11,0,139,144,
        3,44,22,0,140,144,3,48,24,0,141,144,3,50,25,0,142,144,3,56,28,0,
        143,138,1,0,0,0,143,139,1,0,0,0,143,140,1,0,0,0,143,141,1,0,0,0,
        143,142,1,0,0,0,144,21,1,0,0,0,145,146,5,1,0,0,146,147,5,29,0,0,
        147,148,3,24,12,0,148,149,5,23,0,0,149,23,1,0,0,0,150,151,3,28,14,
        0,151,152,3,26,13,0,152,25,1,0,0,0,153,154,5,33,0,0,154,162,3,28,
        14,0,155,156,5,32,0,0,156,162,3,28,14,0,157,158,5,26,0,0,158,162,
        3,28,14,0,159,160,5,31,0,0,160,162,3,28,14,0,161,153,1,0,0,0,161,
        155,1,0,0,0,161,157,1,0,0,0,161,159,1,0,0,0,161,162,1,0,0,0,162,
        27,1,0,0,0,163,164,3,32,16,0,164,165,3,30,15,0,165,29,1,0,0,0,166,
        167,5,25,0,0,167,171,3,28,14,0,168,169,5,26,0,0,169,171,3,28,14,
        0,170,166,1,0,0,0,170,168,1,0,0,0,170,171,1,0,0,0,171,31,1,0,0,0,
        172,173,3,36,18,0,173,174,3,34,17,0,174,33,1,0,0,0,175,176,5,27,
        0,0,176,180,3,32,16,0,177,178,5,28,0,0,178,180,3,32,16,0,179,175,
        1,0,0,0,179,177,1,0,0,0,179,180,1,0,0,0,180,35,1,0,0,0,181,182,5,
        18,0,0,182,183,3,24,12,0,183,184,5,19,0,0,184,189,1,0,0,0,185,186,
        3,38,19,0,186,187,3,40,20,0,187,189,1,0,0,0,188,181,1,0,0,0,188,
        185,1,0,0,0,189,37,1,0,0,0,190,192,7,1,0,0,191,190,1,0,0,0,191,192,
        1,0,0,0,192,39,1,0,0,0,193,196,5,1,0,0,194,196,3,42,21,0,195,193,
        1,0,0,0,195,194,1,0,0,0,196,41,1,0,0,0,197,198,7,2,0,0,198,43,1,
        0,0,0,199,200,5,9,0,0,200,201,5,18,0,0,201,202,3,24,12,0,202,203,
        5,19,0,0,203,204,5,17,0,0,204,205,3,16,8,0,205,206,3,46,23,0,206,
        207,5,23,0,0,207,45,1,0,0,0,208,209,5,10,0,0,209,211,3,16,8,0,210,
        208,1,0,0,0,210,211,1,0,0,0,211,47,1,0,0,0,212,213,5,8,0,0,213,214,
        5,18,0,0,214,215,3,24,12,0,215,216,5,19,0,0,216,217,5,17,0,0,217,
        218,3,16,8,0,218,219,5,23,0,0,219,49,1,0,0,0,220,221,5,1,0,0,221,
        222,5,18,0,0,222,223,3,52,26,0,223,224,5,19,0,0,224,225,5,23,0,0,
        225,51,1,0,0,0,226,228,3,54,27,0,227,226,1,0,0,0,227,228,1,0,0,0,
        228,53,1,0,0,0,229,235,3,24,12,0,230,231,3,24,12,0,231,232,5,22,
        0,0,232,233,3,54,27,0,233,235,1,0,0,0,234,229,1,0,0,0,234,230,1,
        0,0,0,235,55,1,0,0,0,236,237,5,13,0,0,237,238,5,18,0,0,238,239,3,
        58,29,0,239,240,5,19,0,0,240,241,5,23,0,0,241,57,1,0,0,0,242,252,
        3,24,12,0,243,252,5,2,0,0,244,245,3,24,12,0,245,246,5,22,0,0,246,
        247,3,58,29,0,247,252,1,0,0,0,248,249,5,2,0,0,249,250,5,22,0,0,250,
        252,3,58,29,0,251,242,1,0,0,0,251,243,1,0,0,0,251,244,1,0,0,0,251,
        248,1,0,0,0,252,59,1,0,0,0,19,71,76,86,93,117,125,127,136,143,161,
        170,179,188,191,195,210,227,234,251
    ]

class PatitoParserParser ( Parser ):

    grammarFileName = "PatitoParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'programa'", "'nula'", "'inicio'", "'mientras'", 
                     "'si'", "'sino'", "'entero'", "'flotante'", "'escribe'", 
                     "'imprime'", "'fin'", "'vars'", "'haz'", "'('", "')'", 
                     "'{'", "'}'", "','", "';'", "':'", "'+'", "'-'", "'*'", 
                     "'/'", "'='", "'!='", "'=='", "'<'", "'>'" ]

    symbolicNames = [ "<INVALID>", "ID", "CTE_LETRERO", "CTE_ENTERO", "CTE_FLOTANTE", 
                      "PROGRAM", "NULA", "INICIO", "MIENTRAS", "SI", "SINO", 
                      "ENTERO", "FLOTANTE", "ESCRIBE", "IMPRIME", "FIN", 
                      "VARS", "HAZ", "LPAREN", "RPAREN", "LBRACE", "RBRACE", 
                      "COMMA", "SEMI", "COLON", "PLUS", "MINUS", "MUL", 
                      "DIV", "EQUAL", "NEQ", "DEQ", "LT", "GT", "WS" ]

    RULE_programa = 0
    RULE_tiene_variables = 1
    RULE_tiene_funciones = 2
    RULE_vars = 3
    RULE_complemento_vars = 4
    RULE_tipo = 5
    RULE_funcs = 6
    RULE_complemento_funcs = 7
    RULE_cuerpo = 8
    RULE_tiene_estatuto = 9
    RULE_estatuto = 10
    RULE_asigna = 11
    RULE_expresion = 12
    RULE_complemento_expresion = 13
    RULE_exp = 14
    RULE_complemento_exp = 15
    RULE_termino = 16
    RULE_complemento_termino = 17
    RULE_factor = 18
    RULE_tiene_signo = 19
    RULE_tiene_var = 20
    RULE_cte = 21
    RULE_condicion = 22
    RULE_complemento_cond = 23
    RULE_ciclo = 24
    RULE_llamada = 25
    RULE_complemento_llamada = 26
    RULE_tiene_expresion = 27
    RULE_imprime = 28
    RULE_complemento_imprime = 29

    ruleNames =  [ "programa", "tiene_variables", "tiene_funciones", "vars", 
                   "complemento_vars", "tipo", "funcs", "complemento_funcs", 
                   "cuerpo", "tiene_estatuto", "estatuto", "asigna", "expresion", 
                   "complemento_expresion", "exp", "complemento_exp", "termino", 
                   "complemento_termino", "factor", "tiene_signo", "tiene_var", 
                   "cte", "condicion", "complemento_cond", "ciclo", "llamada", 
                   "complemento_llamada", "tiene_expresion", "imprime", 
                   "complemento_imprime" ]

    EOF = Token.EOF
    ID=1
    CTE_LETRERO=2
    CTE_ENTERO=3
    CTE_FLOTANTE=4
    PROGRAM=5
    NULA=6
    INICIO=7
    MIENTRAS=8
    SI=9
    SINO=10
    ENTERO=11
    FLOTANTE=12
    ESCRIBE=13
    IMPRIME=14
    FIN=15
    VARS=16
    HAZ=17
    LPAREN=18
    RPAREN=19
    LBRACE=20
    RBRACE=21
    COMMA=22
    SEMI=23
    COLON=24
    PLUS=25
    MINUS=26
    MUL=27
    DIV=28
    EQUAL=29
    NEQ=30
    DEQ=31
    LT=32
    GT=33
    WS=34

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._ID = None # Token

        def PROGRAM(self):
            return self.getToken(PatitoParserParser.PROGRAM, 0)

        def ID(self):
            return self.getToken(PatitoParserParser.ID, 0)

        def SEMI(self):
            return self.getToken(PatitoParserParser.SEMI, 0)

        def tiene_variables(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_variablesContext,0)


        def tiene_funciones(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_funcionesContext,0)


        def INICIO(self):
            return self.getToken(PatitoParserParser.INICIO, 0)

        def cuerpo(self):
            return self.getTypedRuleContext(PatitoParserParser.CuerpoContext,0)


        def FIN(self):
            return self.getToken(PatitoParserParser.FIN, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_programa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrograma" ):
                listener.enterPrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrograma" ):
                listener.exitPrograma(self)




    def programa(self):

        localctx = PatitoParserParser.ProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_programa)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 60
            self.match(PatitoParserParser.PROGRAM)
            self.state = 61
            localctx._ID = self.match(PatitoParserParser.ID)

            self.nombrefuncion = (None if localctx._ID is None else localctx._ID.text)
            self.funcdir.add_funcion((None if localctx._ID is None else localctx._ID.text),"programa")

            self.state = 63
            self.match(PatitoParserParser.SEMI)
            self.state = 64
            self.tiene_variables()
            self.state = 65
            self.tiene_funciones()
            self.state = 66
            self.match(PatitoParserParser.INICIO)
            self.state = 67
            self.cuerpo()
            self.state = 68
            self.match(PatitoParserParser.FIN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Tiene_variablesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def vars_(self):
            return self.getTypedRuleContext(PatitoParserParser.VarsContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_tiene_variables

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTiene_variables" ):
                listener.enterTiene_variables(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTiene_variables" ):
                listener.exitTiene_variables(self)




    def tiene_variables(self):

        localctx = PatitoParserParser.Tiene_variablesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_tiene_variables)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 71
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==16:
                self.state = 70
                self.vars_()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Tiene_funcionesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def funcs(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PatitoParserParser.FuncsContext)
            else:
                return self.getTypedRuleContext(PatitoParserParser.FuncsContext,i)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_tiene_funciones

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTiene_funciones" ):
                listener.enterTiene_funciones(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTiene_funciones" ):
                listener.exitTiene_funciones(self)




    def tiene_funciones(self):

        localctx = PatitoParserParser.Tiene_funcionesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_tiene_funciones)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 76
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==6:
                self.state = 73
                self.funcs()
                self.state = 78
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._complemento_vars = None # Complemento_varsContext

        def VARS(self):
            return self.getToken(PatitoParserParser.VARS, 0)

        def complemento_vars(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PatitoParserParser.Complemento_varsContext)
            else:
                return self.getTypedRuleContext(PatitoParserParser.Complemento_varsContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(PatitoParserParser.SEMI)
            else:
                return self.getToken(PatitoParserParser.SEMI, i)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_vars

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVars" ):
                listener.enterVars(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVars" ):
                listener.exitVars(self)




    def vars_(self):

        localctx = PatitoParserParser.VarsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_vars)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 79
            self.match(PatitoParserParser.VARS)
            self.state = 84 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 80
                localctx._complemento_vars = self.complemento_vars()

                partes = (None if localctx._complemento_vars is None else self._input.getText(localctx._complemento_vars.start,localctx._complemento_vars.stop)).split(":")  
                variables_separadas = partes[0].split(",")
                tipo = partes[1] 
                for variable in variables_separadas: 
                    self.funcdir.funciones[self.nombrefuncion]["tabla"].add_var(variable,tipo)

                self.state = 82
                self.match(PatitoParserParser.SEMI)
                self.state = 86 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==1):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Complemento_varsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(PatitoParserParser.ID)
            else:
                return self.getToken(PatitoParserParser.ID, i)

        def COLON(self):
            return self.getToken(PatitoParserParser.COLON, 0)

        def tipo(self):
            return self.getTypedRuleContext(PatitoParserParser.TipoContext,0)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PatitoParserParser.COMMA)
            else:
                return self.getToken(PatitoParserParser.COMMA, i)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_complemento_vars

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplemento_vars" ):
                listener.enterComplemento_vars(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplemento_vars" ):
                listener.exitComplemento_vars(self)




    def complemento_vars(self):

        localctx = PatitoParserParser.Complemento_varsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_complemento_vars)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 88
            self.match(PatitoParserParser.ID)
            self.state = 93
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22:
                self.state = 89
                self.match(PatitoParserParser.COMMA)
                self.state = 90
                self.match(PatitoParserParser.ID)
                self.state = 95
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 96
            self.match(PatitoParserParser.COLON)
            self.state = 97
            self.tipo()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TipoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ENTERO(self):
            return self.getToken(PatitoParserParser.ENTERO, 0)

        def FLOTANTE(self):
            return self.getToken(PatitoParserParser.FLOTANTE, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_tipo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTipo" ):
                listener.enterTipo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTipo" ):
                listener.exitTipo(self)




    def tipo(self):

        localctx = PatitoParserParser.TipoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_tipo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            _la = self._input.LA(1)
            if not(_la==11 or _la==12):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._ID = None # Token
            self._complemento_funcs = None # Complemento_funcsContext

        def NULA(self):
            return self.getToken(PatitoParserParser.NULA, 0)

        def ID(self):
            return self.getToken(PatitoParserParser.ID, 0)

        def LPAREN(self):
            return self.getToken(PatitoParserParser.LPAREN, 0)

        def complemento_funcs(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_funcsContext,0)


        def RPAREN(self):
            return self.getToken(PatitoParserParser.RPAREN, 0)

        def LBRACE(self):
            return self.getToken(PatitoParserParser.LBRACE, 0)

        def tiene_variables(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_variablesContext,0)


        def cuerpo(self):
            return self.getTypedRuleContext(PatitoParserParser.CuerpoContext,0)


        def RBRACE(self):
            return self.getToken(PatitoParserParser.RBRACE, 0)

        def SEMI(self):
            return self.getToken(PatitoParserParser.SEMI, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_funcs

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncs" ):
                listener.enterFuncs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncs" ):
                listener.exitFuncs(self)




    def funcs(self):

        localctx = PatitoParserParser.FuncsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_funcs)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 101
            self.match(PatitoParserParser.NULA)
            self.state = 102
            localctx._ID = self.match(PatitoParserParser.ID)

            self.nombrefuncion = (None if localctx._ID is None else localctx._ID.text)
            self.funcdir.add_funcion((None if localctx._ID is None else localctx._ID.text),"nula")

            self.state = 104
            self.match(PatitoParserParser.LPAREN)
            self.state = 105
            localctx._complemento_funcs = self.complemento_funcs()

            argumentos = (None if localctx._complemento_funcs is None else self._input.getText(localctx._complemento_funcs.start,localctx._complemento_funcs.stop)).split(",")  
            for argumento in argumentos: 
                arg_div = argumento.split(":")
                variable = arg_div[0]
                tipo = arg_div[1]
                self.funcdir.funciones[self.nombrefuncion]["tabla"].add_var(variable,tipo)

            self.state = 107
            self.match(PatitoParserParser.RPAREN)
            self.state = 108
            self.match(PatitoParserParser.LBRACE)
            self.state = 109
            self.tiene_variables()
            self.state = 110
            self.cuerpo()
            self.state = 111
            self.match(PatitoParserParser.RBRACE)
            self.state = 112
            self.match(PatitoParserParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Complemento_funcsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PatitoParserParser.ID, 0)

        def COLON(self):
            return self.getToken(PatitoParserParser.COLON, 0)

        def tipo(self):
            return self.getTypedRuleContext(PatitoParserParser.TipoContext,0)


        def COMMA(self):
            return self.getToken(PatitoParserParser.COMMA, 0)

        def complemento_funcs(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_funcsContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_complemento_funcs

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplemento_funcs" ):
                listener.enterComplemento_funcs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplemento_funcs" ):
                listener.exitComplemento_funcs(self)




    def complemento_funcs(self):

        localctx = PatitoParserParser.Complemento_funcsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_complemento_funcs)
        self._la = 0 # Token type
        try:
            self.state = 127
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 117
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 114
                    self.match(PatitoParserParser.ID)
                    self.state = 115
                    self.match(PatitoParserParser.COLON)
                    self.state = 116
                    self.tipo()


                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 125
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 119
                    self.match(PatitoParserParser.ID)
                    self.state = 120
                    self.match(PatitoParserParser.COLON)
                    self.state = 121
                    self.tipo()
                    self.state = 122
                    self.match(PatitoParserParser.COMMA)
                    self.state = 123
                    self.complemento_funcs()


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CuerpoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(PatitoParserParser.LBRACE, 0)

        def tiene_estatuto(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_estatutoContext,0)


        def RBRACE(self):
            return self.getToken(PatitoParserParser.RBRACE, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_cuerpo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCuerpo" ):
                listener.enterCuerpo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCuerpo" ):
                listener.exitCuerpo(self)




    def cuerpo(self):

        localctx = PatitoParserParser.CuerpoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_cuerpo)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 129
            self.match(PatitoParserParser.LBRACE)
            self.state = 130
            self.tiene_estatuto()
            self.state = 131
            self.match(PatitoParserParser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Tiene_estatutoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def estatuto(self):
            return self.getTypedRuleContext(PatitoParserParser.EstatutoContext,0)


        def tiene_estatuto(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_estatutoContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_tiene_estatuto

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTiene_estatuto" ):
                listener.enterTiene_estatuto(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTiene_estatuto" ):
                listener.exitTiene_estatuto(self)




    def tiene_estatuto(self):

        localctx = PatitoParserParser.Tiene_estatutoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_tiene_estatuto)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 136
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8962) != 0):
                self.state = 133
                self.estatuto()
                self.state = 134
                self.tiene_estatuto()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EstatutoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def asigna(self):
            return self.getTypedRuleContext(PatitoParserParser.AsignaContext,0)


        def condicion(self):
            return self.getTypedRuleContext(PatitoParserParser.CondicionContext,0)


        def ciclo(self):
            return self.getTypedRuleContext(PatitoParserParser.CicloContext,0)


        def llamada(self):
            return self.getTypedRuleContext(PatitoParserParser.LlamadaContext,0)


        def imprime(self):
            return self.getTypedRuleContext(PatitoParserParser.ImprimeContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_estatuto

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEstatuto" ):
                listener.enterEstatuto(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEstatuto" ):
                listener.exitEstatuto(self)




    def estatuto(self):

        localctx = PatitoParserParser.EstatutoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_estatuto)
        try:
            self.state = 143
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 138
                self.asigna()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 139
                self.condicion()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 140
                self.ciclo()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 141
                self.llamada()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 142
                self.imprime()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AsignaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PatitoParserParser.ID, 0)

        def EQUAL(self):
            return self.getToken(PatitoParserParser.EQUAL, 0)

        def expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpresionContext,0)


        def SEMI(self):
            return self.getToken(PatitoParserParser.SEMI, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_asigna

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsigna" ):
                listener.enterAsigna(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsigna" ):
                listener.exitAsigna(self)




    def asigna(self):

        localctx = PatitoParserParser.AsignaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_asigna)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self.match(PatitoParserParser.ID)
            self.state = 146
            self.match(PatitoParserParser.EQUAL)
            self.state = 147
            self.expresion()
            self.state = 148
            self.match(PatitoParserParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpresionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpContext,0)


        def complemento_expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_expresionContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_expresion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpresion" ):
                listener.enterExpresion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpresion" ):
                listener.exitExpresion(self)




    def expresion(self):

        localctx = PatitoParserParser.ExpresionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_expresion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self.exp()
            self.state = 151
            self.complemento_expresion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Complemento_expresionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GT(self):
            return self.getToken(PatitoParserParser.GT, 0)

        def exp(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpContext,0)


        def LT(self):
            return self.getToken(PatitoParserParser.LT, 0)

        def MINUS(self):
            return self.getToken(PatitoParserParser.MINUS, 0)

        def DEQ(self):
            return self.getToken(PatitoParserParser.DEQ, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_complemento_expresion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplemento_expresion" ):
                listener.enterComplemento_expresion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplemento_expresion" ):
                listener.exitComplemento_expresion(self)




    def complemento_expresion(self):

        localctx = PatitoParserParser.Complemento_expresionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_complemento_expresion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 161
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [33]:
                self.state = 153
                self.match(PatitoParserParser.GT)
                self.state = 154
                self.exp()
                pass
            elif token in [32]:
                self.state = 155
                self.match(PatitoParserParser.LT)
                self.state = 156
                self.exp()
                pass
            elif token in [26]:
                self.state = 157
                self.match(PatitoParserParser.MINUS)
                self.state = 158
                self.exp()
                pass
            elif token in [31]:
                self.state = 159
                self.match(PatitoParserParser.DEQ)
                self.state = 160
                self.exp()
                pass
            elif token in [19, 22, 23]:
                pass
            else:
                pass
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def termino(self):
            return self.getTypedRuleContext(PatitoParserParser.TerminoContext,0)


        def complemento_exp(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_expContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_exp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExp" ):
                listener.enterExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExp" ):
                listener.exitExp(self)




    def exp(self):

        localctx = PatitoParserParser.ExpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_exp)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 163
            self.termino()
            self.state = 164
            self.complemento_exp()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Complemento_expContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(PatitoParserParser.PLUS, 0)

        def exp(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpContext,0)


        def MINUS(self):
            return self.getToken(PatitoParserParser.MINUS, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_complemento_exp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplemento_exp" ):
                listener.enterComplemento_exp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplemento_exp" ):
                listener.exitComplemento_exp(self)




    def complemento_exp(self):

        localctx = PatitoParserParser.Complemento_expContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_complemento_exp)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.state = 166
                self.match(PatitoParserParser.PLUS)
                self.state = 167
                self.exp()

            elif la_ == 2:
                self.state = 168
                self.match(PatitoParserParser.MINUS)
                self.state = 169
                self.exp()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TerminoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def factor(self):
            return self.getTypedRuleContext(PatitoParserParser.FactorContext,0)


        def complemento_termino(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_terminoContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_termino

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTermino" ):
                listener.enterTermino(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTermino" ):
                listener.exitTermino(self)




    def termino(self):

        localctx = PatitoParserParser.TerminoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_termino)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 172
            self.factor()
            self.state = 173
            self.complemento_termino()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Complemento_terminoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MUL(self):
            return self.getToken(PatitoParserParser.MUL, 0)

        def termino(self):
            return self.getTypedRuleContext(PatitoParserParser.TerminoContext,0)


        def DIV(self):
            return self.getToken(PatitoParserParser.DIV, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_complemento_termino

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplemento_termino" ):
                listener.enterComplemento_termino(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplemento_termino" ):
                listener.exitComplemento_termino(self)




    def complemento_termino(self):

        localctx = PatitoParserParser.Complemento_terminoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_complemento_termino)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 179
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [27]:
                self.state = 175
                self.match(PatitoParserParser.MUL)
                self.state = 176
                self.termino()
                pass
            elif token in [28]:
                self.state = 177
                self.match(PatitoParserParser.DIV)
                self.state = 178
                self.termino()
                pass
            elif token in [19, 22, 23, 25, 26, 31, 32, 33]:
                pass
            else:
                pass
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(PatitoParserParser.LPAREN, 0)

        def expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpresionContext,0)


        def RPAREN(self):
            return self.getToken(PatitoParserParser.RPAREN, 0)

        def tiene_signo(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_signoContext,0)


        def tiene_var(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_varContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor" ):
                listener.enterFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor" ):
                listener.exitFactor(self)




    def factor(self):

        localctx = PatitoParserParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_factor)
        try:
            self.state = 188
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [18]:
                self.enterOuterAlt(localctx, 1)
                self.state = 181
                self.match(PatitoParserParser.LPAREN)
                self.state = 182
                self.expresion()
                self.state = 183
                self.match(PatitoParserParser.RPAREN)
                pass
            elif token in [1, 3, 4, 25, 26]:
                self.enterOuterAlt(localctx, 2)
                self.state = 185
                self.tiene_signo()
                self.state = 186
                self.tiene_var()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Tiene_signoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(PatitoParserParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(PatitoParserParser.MINUS, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_tiene_signo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTiene_signo" ):
                listener.enterTiene_signo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTiene_signo" ):
                listener.exitTiene_signo(self)




    def tiene_signo(self):

        localctx = PatitoParserParser.Tiene_signoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_tiene_signo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==25 or _la==26:
                self.state = 190
                _la = self._input.LA(1)
                if not(_la==25 or _la==26):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Tiene_varContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PatitoParserParser.ID, 0)

        def cte(self):
            return self.getTypedRuleContext(PatitoParserParser.CteContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_tiene_var

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTiene_var" ):
                listener.enterTiene_var(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTiene_var" ):
                listener.exitTiene_var(self)




    def tiene_var(self):

        localctx = PatitoParserParser.Tiene_varContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_tiene_var)
        try:
            self.state = 195
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.enterOuterAlt(localctx, 1)
                self.state = 193
                self.match(PatitoParserParser.ID)
                pass
            elif token in [3, 4]:
                self.enterOuterAlt(localctx, 2)
                self.state = 194
                self.cte()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CteContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CTE_ENTERO(self):
            return self.getToken(PatitoParserParser.CTE_ENTERO, 0)

        def CTE_FLOTANTE(self):
            return self.getToken(PatitoParserParser.CTE_FLOTANTE, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_cte

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCte" ):
                listener.enterCte(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCte" ):
                listener.exitCte(self)




    def cte(self):

        localctx = PatitoParserParser.CteContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_cte)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 197
            _la = self._input.LA(1)
            if not(_la==3 or _la==4):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CondicionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SI(self):
            return self.getToken(PatitoParserParser.SI, 0)

        def LPAREN(self):
            return self.getToken(PatitoParserParser.LPAREN, 0)

        def expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpresionContext,0)


        def RPAREN(self):
            return self.getToken(PatitoParserParser.RPAREN, 0)

        def HAZ(self):
            return self.getToken(PatitoParserParser.HAZ, 0)

        def cuerpo(self):
            return self.getTypedRuleContext(PatitoParserParser.CuerpoContext,0)


        def complemento_cond(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_condContext,0)


        def SEMI(self):
            return self.getToken(PatitoParserParser.SEMI, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_condicion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondicion" ):
                listener.enterCondicion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondicion" ):
                listener.exitCondicion(self)




    def condicion(self):

        localctx = PatitoParserParser.CondicionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_condicion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 199
            self.match(PatitoParserParser.SI)
            self.state = 200
            self.match(PatitoParserParser.LPAREN)
            self.state = 201
            self.expresion()
            self.state = 202
            self.match(PatitoParserParser.RPAREN)
            self.state = 203
            self.match(PatitoParserParser.HAZ)
            self.state = 204
            self.cuerpo()
            self.state = 205
            self.complemento_cond()
            self.state = 206
            self.match(PatitoParserParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Complemento_condContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SINO(self):
            return self.getToken(PatitoParserParser.SINO, 0)

        def cuerpo(self):
            return self.getTypedRuleContext(PatitoParserParser.CuerpoContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_complemento_cond

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplemento_cond" ):
                listener.enterComplemento_cond(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplemento_cond" ):
                listener.exitComplemento_cond(self)




    def complemento_cond(self):

        localctx = PatitoParserParser.Complemento_condContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_complemento_cond)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 210
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 208
                self.match(PatitoParserParser.SINO)
                self.state = 209
                self.cuerpo()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CicloContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MIENTRAS(self):
            return self.getToken(PatitoParserParser.MIENTRAS, 0)

        def LPAREN(self):
            return self.getToken(PatitoParserParser.LPAREN, 0)

        def expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpresionContext,0)


        def RPAREN(self):
            return self.getToken(PatitoParserParser.RPAREN, 0)

        def HAZ(self):
            return self.getToken(PatitoParserParser.HAZ, 0)

        def cuerpo(self):
            return self.getTypedRuleContext(PatitoParserParser.CuerpoContext,0)


        def SEMI(self):
            return self.getToken(PatitoParserParser.SEMI, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_ciclo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCiclo" ):
                listener.enterCiclo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCiclo" ):
                listener.exitCiclo(self)




    def ciclo(self):

        localctx = PatitoParserParser.CicloContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_ciclo)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 212
            self.match(PatitoParserParser.MIENTRAS)
            self.state = 213
            self.match(PatitoParserParser.LPAREN)
            self.state = 214
            self.expresion()
            self.state = 215
            self.match(PatitoParserParser.RPAREN)
            self.state = 216
            self.match(PatitoParserParser.HAZ)
            self.state = 217
            self.cuerpo()
            self.state = 218
            self.match(PatitoParserParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LlamadaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(PatitoParserParser.ID, 0)

        def LPAREN(self):
            return self.getToken(PatitoParserParser.LPAREN, 0)

        def complemento_llamada(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_llamadaContext,0)


        def RPAREN(self):
            return self.getToken(PatitoParserParser.RPAREN, 0)

        def SEMI(self):
            return self.getToken(PatitoParserParser.SEMI, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_llamada

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLlamada" ):
                listener.enterLlamada(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLlamada" ):
                listener.exitLlamada(self)




    def llamada(self):

        localctx = PatitoParserParser.LlamadaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_llamada)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 220
            self.match(PatitoParserParser.ID)
            self.state = 221
            self.match(PatitoParserParser.LPAREN)
            self.state = 222
            self.complemento_llamada()
            self.state = 223
            self.match(PatitoParserParser.RPAREN)
            self.state = 224
            self.match(PatitoParserParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Complemento_llamadaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tiene_expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_expresionContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_complemento_llamada

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplemento_llamada" ):
                listener.enterComplemento_llamada(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplemento_llamada" ):
                listener.exitComplemento_llamada(self)




    def complemento_llamada(self):

        localctx = PatitoParserParser.Complemento_llamadaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_complemento_llamada)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 227
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 100925466) != 0):
                self.state = 226
                self.tiene_expresion()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Tiene_expresionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpresionContext,0)


        def COMMA(self):
            return self.getToken(PatitoParserParser.COMMA, 0)

        def tiene_expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.Tiene_expresionContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_tiene_expresion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTiene_expresion" ):
                listener.enterTiene_expresion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTiene_expresion" ):
                listener.exitTiene_expresion(self)




    def tiene_expresion(self):

        localctx = PatitoParserParser.Tiene_expresionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_tiene_expresion)
        try:
            self.state = 234
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 229
                self.expresion()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 230
                self.expresion()
                self.state = 231
                self.match(PatitoParserParser.COMMA)
                self.state = 232
                self.tiene_expresion()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImprimeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ESCRIBE(self):
            return self.getToken(PatitoParserParser.ESCRIBE, 0)

        def LPAREN(self):
            return self.getToken(PatitoParserParser.LPAREN, 0)

        def complemento_imprime(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_imprimeContext,0)


        def RPAREN(self):
            return self.getToken(PatitoParserParser.RPAREN, 0)

        def SEMI(self):
            return self.getToken(PatitoParserParser.SEMI, 0)

        def getRuleIndex(self):
            return PatitoParserParser.RULE_imprime

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImprime" ):
                listener.enterImprime(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImprime" ):
                listener.exitImprime(self)




    def imprime(self):

        localctx = PatitoParserParser.ImprimeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_imprime)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 236
            self.match(PatitoParserParser.ESCRIBE)
            self.state = 237
            self.match(PatitoParserParser.LPAREN)
            self.state = 238
            self.complemento_imprime()
            self.state = 239
            self.match(PatitoParserParser.RPAREN)
            self.state = 240
            self.match(PatitoParserParser.SEMI)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Complemento_imprimeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expresion(self):
            return self.getTypedRuleContext(PatitoParserParser.ExpresionContext,0)


        def CTE_LETRERO(self):
            return self.getToken(PatitoParserParser.CTE_LETRERO, 0)

        def COMMA(self):
            return self.getToken(PatitoParserParser.COMMA, 0)

        def complemento_imprime(self):
            return self.getTypedRuleContext(PatitoParserParser.Complemento_imprimeContext,0)


        def getRuleIndex(self):
            return PatitoParserParser.RULE_complemento_imprime

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComplemento_imprime" ):
                listener.enterComplemento_imprime(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComplemento_imprime" ):
                listener.exitComplemento_imprime(self)




    def complemento_imprime(self):

        localctx = PatitoParserParser.Complemento_imprimeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_complemento_imprime)
        try:
            self.state = 251
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 242
                self.expresion()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 243
                self.match(PatitoParserParser.CTE_LETRERO)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 244
                self.expresion()
                self.state = 245
                self.match(PatitoParserParser.COMMA)
                self.state = 246
                self.complemento_imprime()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 248
                self.match(PatitoParserParser.CTE_LETRERO)
                self.state = 249
                self.match(PatitoParserParser.COMMA)
                self.state = 250
                self.complemento_imprime()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





